import "./ChatInput.css";

function ChatInput({
  question,
  setQuestion,
  askQuestion
}) {
  return (
    <div className="chat-input">

      <input
        type="text"
        placeholder="Ask a programming question..."
        value={question}
        onChange={(e)=>setQuestion(e.target.value)}
        onKeyDown={(e)=>{
          if(e.key==="Enter"){
            askQuestion();
          }
        }}
      />

      <button onClick={askQuestion}>
        Send
      </button>

    </div>
  );
}

export default ChatInput;