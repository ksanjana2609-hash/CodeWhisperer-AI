import "./Header.css";

function Header() {
  return (
    <header className="header">
      <div className="logo">
        🤖 <span>CodeWhisperer AI</span>
      </div>

      <div className="tagline">
        Your Personal Programming Tutor
      </div>
    </header>
  );
}

export default Header;