import { useState } from "react";
import Header from "./Header";
import Sidebar from "./Sidebar";
import ChatWindow from "./ChatWindow";
import ChatInput from "./ChatInput";
import "./Home.css";

function Home() {
  const [messages, setMessages] = useState([]);
  const [question, setQuestion] = useState("");
  const [loading, setLoading] = useState(false);

  async function askQuestion() {
    if (!question.trim()) return;

    const userQuestion = question;

    setMessages((prev) => [
      ...prev,
      { sender: "user", text: userQuestion },
    ]);

    setQuestion("");
    setLoading(true);

    try {
      const response = await fetch("http://127.0.0.1:8000/ask", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          question: userQuestion,
        }),
      });

      const data = await response.json();

      setMessages((prev) => [
        ...prev,
        {
          sender: "ai",
          text: data.response,
        },
      ]);
    } catch (error) {
      setMessages((prev) => [
        ...prev,
        {
          sender: "ai",
          text: "❌ Unable to connect to the server.",
        },
      ]);
    }

    setLoading(false);
  }

  return (
    <div className="home">
      <Header />

      <div className="main-layout">
        <Sidebar />

        <div className="chat-section">
          <ChatWindow
            messages={messages}
            loading={loading}
          />

          <ChatInput
            question={question}
            setQuestion={setQuestion}
            askQuestion={askQuestion}
          />
        </div>
      </div>
    </div>
  );
}

export default Home;