import { useEffect, useRef } from "react";
import MessageBubble from "./MessageBubble";
import Loader from "./Loader";
import "./ChatWindow.css";

function ChatWindow({ messages, loading }) {
  const bottomRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({
      behavior: "smooth",
    });
  }, [messages, loading]);

  return (
    <div className="chat-window">
      {messages.length === 0 && (
        <div className="welcome">
          <h2>👋 Welcome to CodeWhisperer AI</h2>

          <p>
            Ask any programming question to get started.
          </p>
        </div>
      )}

      {messages.map((msg, index) => (
        <MessageBubble
          key={index}
          sender={msg.sender}
          text={msg.text}
        />
      ))}

      {loading && <Loader />}

      <div ref={bottomRef}></div>
    </div>
  );
}

export default ChatWindow;