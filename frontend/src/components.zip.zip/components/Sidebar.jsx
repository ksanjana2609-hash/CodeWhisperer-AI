import "./Sidebar.css";
import { FaPlus, FaComments } from "react-icons/fa";

function Sidebar() {
  return (
    <div className="sidebar">

      <h2 className="logo">
        🤖 CodeWhisperer
      </h2>

      <button className="new-chat-btn">
        <FaPlus />
        <span>New Chat</span>
      </button>

      <div className="history">

        <h3>Recent Chats</h3>

        <div className="history-item">
          <FaComments />
          <span>What is C++?</span>
        </div>

        <div className="history-item">
          <FaComments />
          <span>Binary Search</span>
        </div>

        <div className="history-item">
          <FaComments />
          <span>Linked List</span>
        </div>

      </div>

    </div>
  );
}

export default Sidebar;